TO:​ Growl

FROM:​ Christian DiVincenzo, Kyle Lagerquist

DATE:​ February 7, 2021

SUBJECT:​ ​ Snarl Sequence Diagram


<img width="953" alt="Screen Shot 2021-02-08 at 5 16 31 PM" src="https://media.github.ccs.neu.edu/user/3912/files/72638a80-6a31-11eb-93ba-68f549b53463">
