TO:​ Growl

FROM:​ Christian DiVincenzo, Kyle Lagerquist 

DATE:​ February 7, 2021

SUBJECT:​ ​ Snarl Project Analysis

## Components
* **Player(s):** A player will be comprised of a name, a location indicating the room that they are in, and a coordinate within the room board.
     * Knowledge: Able to see a limited area around them, whether or not they have unlocked the exit, their own location.
* **Adversaries:** An adversary will consist of a location indicating the room that they are in, and a coordinate within the room board.
    * Knowledge: Entire level, including player(s) locations, exit and key locations.
    * Code will be supplied by others, will be automated.
* **Stratergy:** Provided code that will determine how the adversary moves.
    * Knowledge: Entire level, including player(s) locations, exit and key locations.
* **Key:** A key to exit the room will have a location coordinate the room it is in.  This will be be  placed in a room.
* **Tile:** A square that may be inhabited by an adversary, an exit, a key, or a player.
     * Knowledge: Whether or not it is inhabited, and what it is inhabitated by. 
* **Exit:** An exit will be  placed in a separate room from the key.
    * Knowledge: Whether or not it is locked.
* **Hallway:** a tile connecting one room to another.
    * Knowledge: Rooms they are connecting.
* **Room:** A room will be a layout consisting of tiles, on a coordinate plane, containing hallways along some edges, possibly an exit. 
    * Knowledge: Hallways, layout, connecting rooms
* **Level:** Consists of multiple rooms and hallways.
    * Knowledge: # of players, # of adversaries, player progress.  
* **Interactive** What the players will interact with, which contains a knowledge of which level a player is on, all the way down.

## Milestones
* **Model** 
* **Command line implementation**
* **Visual GUI** 
* **Interactive GUI** 
* **Local Play** 
* **Stratergy Update Implementation** 
* **Server Connection** 
* **Complete Game** 



